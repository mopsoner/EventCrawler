/**
 * Bizouk Chat Widget
 * Remplacement de Chatbase avec IA native (OpenAI/Claude)
 *
 * Usage:
 *   <script src="/js/chat-widget.js"></script>
 *   <script>
 *     BzkChat.init({ apiUrl: '/api/chat' });
 *   </script>
 */
(function () {
    'use strict';

    var BzkChat = {
        // Configuration
        config: {
            apiUrl: '/api/chat',
            welcomeMessage: "Bonjour ! Je suis l'assistant Bizouk. Comment puis-je vous aider ?",
            placeholder: 'Tapez votre message...',
            title: 'Assistant Bizouk',
            subtitle: 'En ligne',
            storageKey: 'bzk_chat_uuid'
        },

        // State
        state: {
            isOpen: false,
            conversationUuid: null,
            isLoading: false,
            isEscalated: false,
            historyLoaded: false,
            pageHistory: [],
            attachments: [],
            // Notation de satisfaction en fin de conversation naturelle
            assistantReplies: 0,
            satisfactionShown: false,
            satisfactionTimer: null
        },

        // Elements cache
        el: {},

        /**
         * Initialise le widget
         */
        init: function (options) {
            if (options) {
                for (var key in options) {
                    if (options.hasOwnProperty(key)) {
                        this.config[key] = options[key];
                    }
                }
            }

            // Récupérer la conversation en cours depuis le localStorage
            this.state.conversationUuid = this.getStoredUuid();

            // Injecter le HTML
            this.render();

            // Cacher les éléments du DOM
            this.cacheElements();

            // Attacher les événements
            this.bindEvents();

            // Si on a une conversation en cours, charger l'historique à l'ouverture
            this.state.historyLoaded = false;

            // Tracker la page courante dans l'historique de navigation
            this.trackPageVisit();

            // Chat proactif — proposer de l'aide sur certaines pages
            this.setupProactiveChat();
        },

        /**
         * Chat proactif : affiche un message sur certaines pages après un délai
         */
        setupProactiveChat: function () {
            var self = this;
            var url = window.location.href;
            var proactiveMessage = null;
            var delay = 15000; // 15 secondes par défaut

            // Pages de paiement — l'utilisateur est peut-être bloqué
            if (url.indexOf('/reservation/paiement') !== -1 || url.indexOf('/stores/reservation/paiement') !== -1) {
                proactiveMessage = 'Un souci avec ton paiement ? Je peux t\'aider !';
                delay = 30000; // 30s sur page paiement
            }
            // Page remboursement
            else if (url.indexOf('refunds-requests') !== -1) {
                proactiveMessage = 'Besoin d\'aide pour ta demande de remboursement ?';
                delay = 20000;
            }
            // Page commande/billets
            else if (url.indexOf('/orders-details') !== -1 || url.indexOf('/attendees-list') !== -1) {
                proactiveMessage = 'Une question sur ta commande ? Je suis là !';
                delay = 25000;
            }

            if (proactiveMessage && !this.state.isOpen) {
                // Ne pas afficher si déjà affiché sur cette page
                var proactiveKey = 'bzk_proactive_' + btoa(url).substring(0, 20);
                if (sessionStorage.getItem(proactiveKey)) return;

                setTimeout(function () {
                    if (self.state.isOpen) return; // Déjà ouvert
                    self.showProactiveBubble(proactiveMessage);
                    sessionStorage.setItem(proactiveKey, '1');
                }, delay);
            }
        },

        /**
         * Affiche une bulle proactive au-dessus du bouton chat
         */
        showProactiveBubble: function (message) {
            var self = window.BzkChat;
            var bubble = document.createElement('div');
            bubble.className = 'bzk-proactive-bubble';
            bubble.innerHTML = '<span>' + message + '</span><button class="bzk-proactive-close">&times;</button>';
            bubble.style.cssText = 'position:fixed;bottom:48px;right:16px;background:#fff;border:1.5px solid #b8860b;'
                + 'border-radius:12px;padding:10px 14px;font-size:13px;color:#333;font-weight:500;'
                + 'box-shadow:0 4px 16px rgba(0,0,0,0.12);z-index:99998;display:flex;align-items:center;gap:8px;'
                + 'max-width:280px;animation:bzkProactiveFadeIn 0.3s ease;cursor:pointer;';

            var style = document.createElement('style');
            style.textContent = '@keyframes bzkProactiveFadeIn{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:translateY(0);}}';
            document.head.appendChild(style);

            bubble.querySelector('.bzk-proactive-close').style.cssText = 'background:none;border:none;color:#999;font-size:16px;cursor:pointer;padding:0 0 0 4px;';
            bubble.querySelector('.bzk-proactive-close').addEventListener('click', function (e) {
                e.stopPropagation();
                bubble.remove();
            });

            bubble.addEventListener('click', function () {
                bubble.remove();
                self.toggleChat();
            });

            document.body.appendChild(bubble);

            // Auto-dismiss après 10s
            setTimeout(function () {
                if (bubble.parentNode) {
                    bubble.style.opacity = '0';
                    bubble.style.transition = 'opacity 0.3s';
                    setTimeout(function () { bubble.remove(); }, 300);
                }
            }, 10000);
        },

        /**
         * Stocke la page courante dans l'historique de navigation (max 20)
         */
        trackPageVisit: function () {
            var entry = {
                url: window.location.href,
                title: document.title,
                ts: new Date().toISOString()
            };
            var history = this.state.pageHistory;
            // Ne pas dupliquer si même URL que la dernière
            if (history.length === 0 || history[history.length - 1].url !== entry.url) {
                history.push(entry);
                if (history.length > 20) history.shift();
            }
        },

        /**
         * Génère le HTML du widget
         */
        render: function () {
            var container = document.createElement('div');
            container.id = 'bzk-chat-widget';
            // Position persistee : br (default) | bl | rv | lv
            var savedPos = this.getSavedPosition();
            container.className = 'bzk-pos-' + savedPos;
            container.innerHTML = this.getTemplate();
            document.body.appendChild(container);
        },

        /**
         * Lit la position persistee dans le localStorage. Valeurs valides :
         *   'br' (bas-droite, default)
         *   'bl' (bas-gauche)
         *   'rv' (rail vertical droite)
         *   'lv' (rail vertical gauche)
         */
        getSavedPosition: function () {
            try {
                var v = localStorage.getItem('bzk_chat_position');
                if (v === 'br' || v === 'bl' || v === 'rv' || v === 'lv') return v;
            } catch (e) {}
            return 'br';
        },

        setPosition: function (pos) {
            if (pos !== 'br' && pos !== 'bl' && pos !== 'rv' && pos !== 'lv') return;
            try { localStorage.setItem('bzk_chat_position', pos); } catch (e) {}
            var container = document.getElementById('bzk-chat-widget');
            if (container) {
                container.className = 'bzk-pos-' + pos;
            }
            // Met a jour l'etat actif des boutons du menu
            var btns = document.querySelectorAll('.bzk-chat-pos-menu button');
            for (var i = 0; i < btns.length; i++) {
                btns[i].classList.toggle('active', btns[i].getAttribute('data-pos') === pos);
            }
        },

        getTemplate: function () {
            return '' +
                '<!-- Bouton flottant -->' +
                '<button class="bzk-chat-toggle" aria-label="Ouvrir le chat">' +
                '  <svg class="icon-chat" viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/></svg>' +
                '  <svg class="icon-close" viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>' +
                '  <span class="bzk-chat-badge">1</span>' +
                '</button>' +
                '' +
                '<!-- Fenêtre de chat -->' +
                '<div class="bzk-chat-window">' +
                '  <!-- Header -->' +
                '  <div class="bzk-chat-header">' +
                '    <div class="bzk-chat-header-avatar">' +
                '      <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>' +
                '    </div>' +
                '    <div class="bzk-chat-header-info">' +
                '      <div class="bzk-chat-header-title">' + this.escapeHtml(this.config.title) + '</div>' +
                '      <div class="bzk-chat-header-status">' + this.escapeHtml(this.config.subtitle) + '</div>' +
                '    </div>' +
                '    <div class="bzk-chat-header-actions">' +
                '      <button class="bzk-chat-header-btn" id="bzk-chat-new-btn" title="Nouvelle conversation">' +
                '        <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>' +
                '      </button>' +
                '      <button class="bzk-chat-header-btn" id="bzk-chat-history-btn" title="Historique">' +
                '        <svg viewBox="0 0 24 24"><path d="M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0 0 13 21a9 9 0 0 0 0-18zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>' +
                '      </button>' +
                '      <button class="bzk-chat-header-btn" id="bzk-chat-position-btn" title="Position du widget">' +
                '        <svg viewBox="0 0 24 24"><path d="M3 3h7v7H3V3zm11 0h7v7h-7V3zM3 14h7v7H3v-7zm11 0h7v7h-7v-7z"/></svg>' +
                '      </button>' +
                '      <div class="bzk-chat-pos-menu" id="bzk-chat-pos-menu">' +
                '        <button data-pos="br" type="button"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 14h6v6h-6z"/><path opacity=".3" d="M4 4h16v16H4z" fill="none" stroke="currentColor"/></svg> Bas droite</button>' +
                '        <button data-pos="bl" type="button"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 14h6v6H4z"/><path opacity=".3" d="M4 4h16v16H4z" fill="none" stroke="currentColor"/></svg> Bas gauche</button>' +
                '        <button data-pos="rv" type="button"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 4h2v16h-2z"/><path opacity=".3" d="M4 4h16v16H4z" fill="none" stroke="currentColor"/></svg> Vertical droite</button>' +
                '        <button data-pos="lv" type="button"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 4h2v16H4z"/><path opacity=".3" d="M4 4h16v16H4z" fill="none" stroke="currentColor"/></svg> Vertical gauche</button>' +
                '      </div>' +
                '      <button class="bzk-chat-header-btn" id="bzk-chat-minimize-btn" title="Reduire">' +
                '        <svg viewBox="0 0 24 24"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z"/></svg>' +
                '      </button>' +
                '    </div>' +
                '  </div>' +
                '' +
                '  <!-- Messages -->' +
                '  <div class="bzk-chat-messages" id="bzk-chat-messages">' +
                '  </div>' +
                '' +
                '  <!-- Typing indicator -->' +
                '  <div class="bzk-chat-typing" id="bzk-chat-typing">' +
                '    <div class="bzk-chat-typing-dot"></div>' +
                '    <div class="bzk-chat-typing-dot"></div>' +
                '    <div class="bzk-chat-typing-dot"></div>' +
                '  </div>' +
                '' +
                '  <!-- Formulaire escalade -->' +
                '  <div class="bzk-chat-escalation" id="bzk-chat-escalation">' +
                '    <h4>Contacter un agent</h4>' +
                '    <div class="bzk-chat-escalation-form">' +
                '      <input type="text" id="bzk-escalation-name" placeholder="Votre nom">' +
                '      <input type="email" id="bzk-escalation-email" placeholder="Votre email">' +
                '      <div class="bzk-chat-escalation-btns">' +
                '        <button class="bzk-chat-escalation-submit" id="bzk-escalation-submit">Envoyer</button>' +
                '        <button class="bzk-chat-escalation-cancel" id="bzk-escalation-cancel">Annuler</button>' +
                '      </div>' +
                '    </div>' +
                '  </div>' +
                '' +
                '  <!-- Satisfaction -->' +
                '  <div class="bzk-chat-satisfaction" id="bzk-chat-satisfaction">' +
                '    <p>Cette conversation vous a-t-elle aidé ?</p>' +
                '    <div class="bzk-chat-satisfaction-stars">' +
                '      <button class="bzk-chat-satisfaction-star" data-rating="1">&#9733;</button>' +
                '      <button class="bzk-chat-satisfaction-star" data-rating="2">&#9733;</button>' +
                '      <button class="bzk-chat-satisfaction-star" data-rating="3">&#9733;</button>' +
                '      <button class="bzk-chat-satisfaction-star" data-rating="4">&#9733;</button>' +
                '      <button class="bzk-chat-satisfaction-star" data-rating="5">&#9733;</button>' +
                '    </div>' +
                '  </div>' +
                '' +
                '  <!-- Zone de saisie -->' +
                '  <div class="bzk-chat-attachment-preview" id="bzk-chat-attachment-preview" style="display:none; padding:8px 12px; border-top:1px solid var(--bzk-chat-border); display:none; flex-wrap:wrap; gap:6px; align-items:center;">' +
                '  </div>' +
                '  <div class="bzk-chat-input-area">' +
                '    <label class="bzk-chat-attach-btn" id="bzk-chat-attach-btn" title="Joindre un fichier">' +
                '      <svg viewBox="0 0 24 24" width="20" height="20"><path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5a2.5 2.5 0 0 1 5 0v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6h-1.5v9.5a2.5 2.5 0 0 0 5 0V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6H16.5z" fill="currentColor"/></svg>' +
                '      <input type="file" id="bzk-chat-file-input" accept="image/*,.pdf" multiple style="display:none;">' +
                '    </label>' +
                '    <textarea class="bzk-chat-input" id="bzk-chat-input" rows="1" placeholder="' + this.escapeHtml(this.config.placeholder) + '"></textarea>' +
                '    <button class="bzk-chat-send-btn" id="bzk-chat-send" disabled>' +
                '      <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>' +
                '    </button>' +
                '  </div>' +
                '' +
                '  <!-- Powered by -->' +
                '  <div class="bzk-chat-powered">Propulsé par Bizouk.com</div>' +
                '' +
                '  <!-- History panel -->' +
                '  <div class="bzk-chat-history-panel" id="bzk-chat-history-panel">' +
                '    <div class="bzk-chat-history-header">' +
                '      <button class="bzk-chat-history-back" id="bzk-chat-history-back">' +
                '        <svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>' +
                '      </button>' +
                '      <span class="bzk-chat-history-title">Conversations</span>' +
                '    </div>' +
                '    <div class="bzk-chat-history-list" id="bzk-chat-history-list">' +
                '      <div style="padding:20px;text-align:center;color:#94a3b8;font-size:13px;">Aucune conversation précédente</div>' +
                '    </div>' +
                '  </div>' +
                '</div>';
        },

        /**
         * Cache les éléments du DOM
         */
        cacheElements: function () {
            this.el.toggle = document.querySelector('.bzk-chat-toggle');
            this.el.window = document.querySelector('.bzk-chat-window');
            this.el.messages = document.getElementById('bzk-chat-messages');
            this.el.input = document.getElementById('bzk-chat-input');
            this.el.sendBtn = document.getElementById('bzk-chat-send');
            this.el.typing = document.getElementById('bzk-chat-typing');
            this.el.escalation = document.getElementById('bzk-chat-escalation');
            this.el.escalationName = document.getElementById('bzk-escalation-name');
            this.el.escalationEmail = document.getElementById('bzk-escalation-email');
            this.el.escalationSubmit = document.getElementById('bzk-escalation-submit');
            this.el.escalationCancel = document.getElementById('bzk-escalation-cancel');
            this.el.satisfaction = document.getElementById('bzk-chat-satisfaction');
            this.el.historyPanel = document.getElementById('bzk-chat-history-panel');
            this.el.historyList = document.getElementById('bzk-chat-history-list');
            this.el.historyBack = document.getElementById('bzk-chat-history-back');
            this.el.newBtn = document.getElementById('bzk-chat-new-btn');
            this.el.historyBtn = document.getElementById('bzk-chat-history-btn');
            this.el.minimizeBtn = document.getElementById('bzk-chat-minimize-btn');
            this.el.positionBtn = document.getElementById('bzk-chat-position-btn');
            this.el.positionMenu = document.getElementById('bzk-chat-pos-menu');
            this.el.fileInput = document.getElementById('bzk-chat-file-input');
            this.el.attachPreview = document.getElementById('bzk-chat-attachment-preview');

            // Marque le bouton actif dans le menu selon la position courante
            if (this.el.positionMenu) {
                var current = this.getSavedPosition();
                var btns = this.el.positionMenu.querySelectorAll('button');
                for (var i = 0; i < btns.length; i++) {
                    btns[i].classList.toggle('active', btns[i].getAttribute('data-pos') === current);
                }
            }
        },

        /**
         * Attache les événements
         */
        bindEvents: function () {
            var self = this;

            // Toggle chat
            this.el.toggle.addEventListener('click', function () {
                self.toggleChat();
            });

            // Envoyer message
            this.el.sendBtn.addEventListener('click', function () {
                self.sendMessage();
            });

            // Input : auto-resize + Enter pour envoyer
            this.el.input.addEventListener('input', function () {
                self.el.sendBtn.disabled = !this.value.trim();
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 100) + 'px';
            });

            this.el.input.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    if (this.value.trim()) {
                        self.sendMessage();
                    }
                }
            });

            // Attachment file input
            this.el.fileInput.addEventListener('change', function () {
                self.handleFileSelect(this);
            });

            // Escalation
            this.el.escalationSubmit.addEventListener('click', function () {
                self.submitEscalation();
            });

            this.el.escalationCancel.addEventListener('click', function () {
                self.hideEscalation();
            });

            // Satisfaction stars
            var stars = document.querySelectorAll('.bzk-chat-satisfaction-star');
            for (var i = 0; i < stars.length; i++) {
                stars[i].addEventListener('click', function () {
                    self.rateSatisfaction(parseInt(this.getAttribute('data-rating')));
                });
            }

            // Nouvelle conversation
            this.el.newBtn.addEventListener('click', function () {
                self.newConversation();
            });

            // Picker position : ouvre/ferme le menu + bind les options
            if (this.el.positionBtn && this.el.positionMenu) {
                this.el.positionBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    self.el.positionMenu.classList.toggle('open');
                });
                var posBtns = this.el.positionMenu.querySelectorAll('button[data-pos]');
                for (var p = 0; p < posBtns.length; p++) {
                    posBtns[p].addEventListener('click', function (e) {
                        e.stopPropagation();
                        self.setPosition(this.getAttribute('data-pos'));
                        self.el.positionMenu.classList.remove('open');
                    });
                }
                // Click ailleurs → ferme le menu
                document.addEventListener('click', function (e) {
                    if (!self.el.positionMenu.contains(e.target)
                        && e.target !== self.el.positionBtn
                        && !self.el.positionBtn.contains(e.target)) {
                        self.el.positionMenu.classList.remove('open');
                    }
                });
            }

            // Historique
            this.el.historyBtn.addEventListener('click', function () {
                self.toggleHistory();
            });

            this.el.historyBack.addEventListener('click', function () {
                self.el.historyPanel.classList.remove('open');
            });

            // Réduire le chat
            this.el.minimizeBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                self.toggleChat();
            });
        },

        /**
         * Ouvre/ferme le chat
         */
        toggleChat: function () {
            this.state.isOpen = !this.state.isOpen;
            this.el.window.classList.toggle('open', this.state.isOpen);
            this.el.toggle.classList.toggle('active', this.state.isOpen);

            if (this.state.isOpen) {
                // Charger l'historique si on a une conversation
                if (this.state.conversationUuid && !this.state.historyLoaded) {
                    this.loadConversation(this.state.conversationUuid);
                } else if (!this.state.conversationUuid && !this.state.historyLoaded) {
                    // Afficher le message de bienvenue
                    this.addMessageToUI('assistant', this.config.welcomeMessage);
                    this.state.historyLoaded = true;
                }

                this.el.input.focus();
                this.scrollToBottom();
            }
        },

        /**
         * Gestion des fichiers attachés
         */
        handleFileSelect: function (input) {
            if (!input.files || input.files.length === 0) return;
            var maxSize = 5 * 1024 * 1024;
            var maxFiles = 10;
            var allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf'];
            var self = this;

            if (self.state.attachments.length + input.files.length > maxFiles) {
                self.addMessageToUI('assistant', 'Maximum ' + maxFiles + ' fichiers à la fois.');
                input.value = '';
                return;
            }

            var filesToProcess = Array.prototype.slice.call(input.files);
            var errors = [];

            filesToProcess.forEach(function(file) {
                if (file.size > maxSize) {
                    errors.push(file.name + ' est trop volumineux (max 5 Mo)');
                    return;
                }
                if (allowedTypes.indexOf(file.type) === -1) {
                    errors.push(file.name + ' : format non supporté');
                    return;
                }

                var reader = new FileReader();
                reader.onload = function (e) {
                    self.state.attachments.push({
                        name: file.name,
                        type: file.type,
                        size: file.size,
                        data: e.target.result
                    });
                    self.renderAttachmentPreviews();
                    self.el.sendBtn.disabled = false;
                };
                reader.readAsDataURL(file);
            });

            if (errors.length > 0) {
                self.addMessageToUI('assistant', errors.join('\n'));
            }
            input.value = '';
        },

        renderAttachmentPreviews: function () {
            var container = this.el.attachPreview;
            var self = this;
            container.innerHTML = '';

            if (this.state.attachments.length === 0) {
                container.style.display = 'none';
                return;
            }

            container.style.display = 'flex';

            this.state.attachments.forEach(function(att, idx) {
                var item = document.createElement('div');
                item.style.cssText = 'position:relative; border-radius:8px; overflow:hidden; border:1px solid var(--bzk-chat-border); background:var(--bzk-chat-bg-secondary);';

                if (att.type.indexOf('image/') === 0) {
                    item.innerHTML = '<img src="' + att.data + '" style="width:48px; height:48px; object-fit:cover; display:block;">'
                        + '<button type="button" data-idx="' + idx + '" style="position:absolute; top:-4px; right:-4px; width:18px; height:18px; border-radius:50%; background:#c62828; color:#fff; border:none; font-size:10px; cursor:pointer; display:flex; align-items:center; justify-content:center;">&times;</button>';
                } else {
                    item.innerHTML = '<div style="width:48px; height:48px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:2px;">'
                        + '<span style="font-size:16px; color:#c62828;">📄</span>'
                        + '<span style="font-size:7px; color:#888; max-width:44px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">' + att.name + '</span></div>'
                        + '<button type="button" data-idx="' + idx + '" style="position:absolute; top:-4px; right:-4px; width:18px; height:18px; border-radius:50%; background:#c62828; color:#fff; border:none; font-size:10px; cursor:pointer; display:flex; align-items:center; justify-content:center;">&times;</button>';
                }

                item.querySelector('button').addEventListener('click', function () {
                    self.removeAttachment(parseInt(this.getAttribute('data-idx')));
                });

                container.appendChild(item);
            });

            // Compteur
            if (this.state.attachments.length > 1) {
                var count = document.createElement('span');
                count.style.cssText = 'font-size:11px; color:var(--bzk-chat-text-muted); font-weight:600;';
                count.textContent = this.state.attachments.length + ' fichiers';
                container.appendChild(count);
            }
        },

        removeAttachment: function (idx) {
            this.state.attachments.splice(idx, 1);
            this.renderAttachmentPreviews();
            if (this.state.attachments.length === 0 && !this.el.input.value.trim()) {
                this.el.sendBtn.disabled = true;
            }
        },

        clearAttachments: function () {
            this.state.attachments = [];
            this.el.fileInput.value = '';
            this.el.attachPreview.style.display = 'none';
            this.el.attachPreview.innerHTML = '';
            if (!this.el.input.value.trim()) this.el.sendBtn.disabled = true;
        },

        /**
         * Envoie un message (avec ou sans pièce jointe)
         */
        sendMessage: function () {
            var message = this.el.input.value.trim();
            var hasAttachments = this.state.attachments.length > 0;
            if ((!message && !hasAttachments) || this.state.isLoading) return;

            // La conversation continue : on annule la proposition de notation
            if (this.state.satisfactionTimer) {
                clearTimeout(this.state.satisfactionTimer);
                this.state.satisfactionTimer = null;
            }

            // Afficher le message utilisateur (avec miniatures)
            var displayMsg = message || '';
            if (hasAttachments) {
                var previewHtml = '<div style="display:flex; flex-wrap:wrap; gap:4px; margin-top:4px;">';
                this.state.attachments.forEach(function(att) {
                    if (att.type.indexOf('image/') === 0) {
                        previewHtml += '<img src="' + att.data + '" style="max-width:100px; max-height:80px; border-radius:6px; display:block;">';
                    } else {
                        previewHtml += '<span style="font-size:11px; color:#888; padding:4px 8px; background:rgba(255,255,255,0.2); border-radius:4px;">📎 ' + att.name + '</span>';
                    }
                });
                previewHtml += '</div>';
                displayMsg += (displayMsg ? '<br>' : '') + previewHtml;
            }
            this.addMessageToUI('user', displayMsg, true, null, message);

            // Vider l'input
            this.el.input.value = '';
            this.el.input.style.height = 'auto';
            this.el.sendBtn.disabled = true;

            // Préparer les données
            var attachNames = this.state.attachments.map(function(a) { return a.name; }).join(', ');
            var sendData = {
                message: message || (hasAttachments ? '[Pièces jointes : ' + attachNames + ']' : ''),
                conversation_uuid: this.state.conversationUuid,
                timezone: '',
                page_url: window.location.href,
                page_title: document.title,
                page_history: JSON.stringify(this.state.pageHistory)
            };

            try { sendData.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch(e) {}

            // Ajouter les pièces jointes
            if (hasAttachments) {
                sendData.attachments = this.state.attachments.map(function(att) {
                    return { name: att.name, type: att.type, size: att.size, data: att.data };
                });
                // Backward compat: envoyer aussi le premier en tant que 'attachment'
                sendData.attachment = sendData.attachments[0];
            }

            // Clear attachments
            this.clearAttachments();

            // Afficher l'indicateur de frappe
            this.showTyping();
            this.state.isLoading = true;

            var self = this;
            self.trackPageVisit();
            this.apiCall('send', sendData, function (data) {
                self.state.isLoading = false;
                self.hideTyping();

                if (data.success) {
                    if (data.conversation_uuid) {
                        self.state.conversationUuid = data.conversation_uuid;
                        self.storeUuid(data.conversation_uuid);
                    }
                    self.addMessageToUI('assistant', data.message);
                    if (data.message) {
                        self.state.assistantReplies++;
                        self.scheduleSatisfactionPrompt();
                    }
                    if (data.should_escalate) {
                        self.showEscalation();
                    }
                } else {
                    if (data.error_debug) console.error('[BzkChat] API error:', data.error_debug, data.error_file || '');
                    self.addMessageToUI('assistant', data.message || data.error || 'Une erreur est survenue.');
                }
            }, function () {
                self.state.isLoading = false;
                self.hideTyping();
                self.addMessageToUI('assistant', 'Désolé, une erreur est survenue. Veuillez réessayer.');
            });
        },

        /**
         * Charge une conversation depuis l'API
         */
        loadConversation: function (uuid) {
            var self = this;
            this.el.messages.innerHTML = '';

            this.apiCall('history', { uuid: uuid }, function (data) {
                if (data.success && data.messages && data.messages.length > 0) {
                    for (var i = 0; i < data.messages.length; i++) {
                        var msg = data.messages[i];
                        // Pour les messages user persistes, msg.message est le
                        // texte brut -> on le passe en rawText pour reactiver
                        // le bouton "Renvoyer" apres un reload de page.
                        var rawText = (msg.type === 'user') ? msg.message : null;
                        self.addMessageToUI(msg.type, msg.message, false, msg.created_at, rawText);
                    }
                    self.state.isEscalated = data.is_escalated || false;

                    if (self.state.isEscalated) {
                        self.showSatisfaction();
                    }
                } else {
                    // Conversation pas trouvée, reset
                    self.state.conversationUuid = null;
                    self.removeStoredUuid();
                    self.addMessageToUI('assistant', self.config.welcomeMessage);
                }
                self.state.historyLoaded = true;
                self.scrollToBottom();
            }, function () {
                self.addMessageToUI('assistant', self.config.welcomeMessage);
                self.state.historyLoaded = true;
            }, 'GET');
        },

        /**
         * Nouvelle conversation
         */
        newConversation: function () {
            this.state.conversationUuid = null;
            this.state.isEscalated = false;
            this.state.historyLoaded = true;
            this.state.assistantReplies = 0;
            this.state.satisfactionShown = false;
            if (this.state.satisfactionTimer) {
                clearTimeout(this.state.satisfactionTimer);
                this.state.satisfactionTimer = null;
            }
            this.removeStoredUuid();
            this.el.messages.innerHTML = '';
            this.hideEscalation();
            this.hideSatisfaction();
            this.el.historyPanel.classList.remove('open');

            var self = this;
            this.apiCall('new', {
                page_url: window.location.href,
                page_title: document.title
            }, function (data) {
                if (data.success) {
                    self.state.conversationUuid = data.conversation_uuid;
                    self.storeUuid(data.conversation_uuid);
                    self.addMessageToUI('assistant', data.message);
                } else {
                    self.addMessageToUI('assistant', self.config.welcomeMessage);
                }
            }, function () {
                self.addMessageToUI('assistant', self.config.welcomeMessage);
            });
        },

        /**
         * Affiche/masque le panel historique
         */
        toggleHistory: function () {
            var isOpen = this.el.historyPanel.classList.contains('open');
            if (isOpen) {
                this.el.historyPanel.classList.remove('open');
            } else {
                this.el.historyPanel.classList.add('open');
                // Pour l'instant, on affiche un message car l'historique
                // des conversations passées nécessite une session utilisateur
                this.el.historyList.innerHTML =
                    '<div style="padding:20px;text-align:center;color:#94a3b8;font-size:13px;">' +
                    'L\'historique des conversations est sauvegardé localement sur cet appareil.' +
                    '</div>';

                if (this.state.conversationUuid) {
                    var self = this;
                    this.el.historyList.innerHTML =
                        '<div class="bzk-chat-history-item" data-uuid="' + this.escapeHtml(this.state.conversationUuid) + '">' +
                        '  <div class="bzk-chat-history-item-title">Conversation en cours</div>' +
                        '  <div class="bzk-chat-history-item-date">Aujourd\'hui</div>' +
                        '</div>';

                    // Attacher le handler de clic
                    var items = this.el.historyList.querySelectorAll('.bzk-chat-history-item');
                    for (var i = 0; i < items.length; i++) {
                        items[i].addEventListener('click', function () {
                            var uuid = this.getAttribute('data-uuid');
                            if (uuid) {
                                self.state.conversationUuid = uuid;
                                self.storeUuid(uuid);
                                self.loadConversation(uuid);
                                self.el.historyPanel.classList.remove('open');
                            }
                        });
                    }
                }
            }
        },

        /**
         * Soumet l'escalade vers Zendesk
         */
        submitEscalation: function () {
            var name = this.el.escalationName.value.trim();
            var email = this.el.escalationEmail.value.trim();

            if (!name || !email) {
                this.el.escalationName.style.borderColor = name ? '' : '#ef4444';
                this.el.escalationEmail.style.borderColor = email ? '' : '#ef4444';
                return;
            }

            // Validation email basique
            if (email.indexOf('@') === -1 || email.indexOf('.') === -1) {
                this.el.escalationEmail.style.borderColor = '#ef4444';
                return;
            }

            this.el.escalationSubmit.textContent = 'Envoi...';
            this.el.escalationSubmit.disabled = true;

            var self = this;
            this.apiCall('escalate', {
                conversation_uuid: this.state.conversationUuid,
                visitor_name: name,
                visitor_email: email
            }, function (data) {
                self.el.escalationSubmit.textContent = 'Envoyer';
                self.el.escalationSubmit.disabled = false;

                if (data.success) {
                    self.hideEscalation();
                    self.addMessageToUI('assistant', data.message);
                    self.state.isEscalated = true;
                    self.showSatisfaction();
                } else {
                    self.addMessageToUI('assistant', data.error || 'Erreur lors de la création du ticket.');
                }
            }, function () {
                self.el.escalationSubmit.textContent = 'Envoyer';
                self.el.escalationSubmit.disabled = false;
                self.addMessageToUI('assistant', 'Erreur lors de la création du ticket. Veuillez contacter support@bizouk.com.');
            });
        },

        /**
         * Note la satisfaction
         */
        rateSatisfaction: function (rating) {
            var stars = document.querySelectorAll('.bzk-chat-satisfaction-star');
            for (var i = 0; i < stars.length; i++) {
                stars[i].classList.toggle('active', parseInt(stars[i].getAttribute('data-rating')) <= rating);
            }

            var self = this;
            this.apiCall('rate', {
                conversation_uuid: this.state.conversationUuid,
                rating: rating
            }, function () {
                setTimeout(function () {
                    self.hideSatisfaction();
                    self.addMessageToUI('assistant', 'Merci pour votre retour !');
                }, 500);
            });
        },

        // ========== UI HELPERS ==========

        addMessageToUI: function (type, content, isRawHtml, timestamp, rawText) {
            if (!content) return;

            var time = timestamp ? this.formatTime(timestamp) : this.formatTime(new Date().toISOString());
            var avatarContent = type === 'assistant' ? 'B' : 'V';
            var renderedContent;
            if (isRawHtml === true) {
                renderedContent = content; // Already contains safe HTML (attachment preview)
            } else if (type === 'assistant') {
                renderedContent = this.renderMarkdown(content);
            } else {
                renderedContent = this.escapeHtml(content);
            }

            var msgDiv = document.createElement('div');
            msgDiv.className = 'bzk-chat-msg ' + type;
            msgDiv.innerHTML =
                '<div class="bzk-chat-msg-avatar">' + avatarContent + '</div>' +
                '<div>' +
                '  <div class="bzk-chat-msg-bubble">' + renderedContent + '</div>' +
                '  <div class="bzk-chat-msg-meta">' +
                '    <span class="bzk-chat-msg-time">' + time + '</span>' +
                '  </div>' +
                '</div>';

            // Bouton "Renvoyer" sous les messages utilisateur. Utile quand la
            // reponse n'arrive pas (timeout, erreur reseau, 400 provider, ...).
            // On stocke le texte brut sur le bouton pour qu'un click rejoue
            // l'envoi sans toucher au DOM existant (on ajoute simplement un
            // nouveau message user en bas).
            if (type === 'user' && rawText) {
                var meta = msgDiv.querySelector('.bzk-chat-msg-meta');
                if (meta) {
                    var retryBtn = document.createElement('button');
                    retryBtn.type = 'button';
                    retryBtn.className = 'bzk-chat-msg-retry';
                    retryBtn.title = 'Renvoyer ce message';
                    retryBtn.setAttribute('aria-label', 'Renvoyer ce message');
                    // Glyphe SVG inline pour ne pas dependre d'une font icon
                    // (le widget peut etre embarque hors du BO ou Line Awesome
                    // n'est pas charge).
                    retryBtn.innerHTML =
                        '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" '
                        + 'stroke="currentColor" stroke-width="2.4" stroke-linecap="round" '
                        + 'stroke-linejoin="round" aria-hidden="true">'
                        + '<polyline points="1 4 1 10 7 10"></polyline>'
                        + '<path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path>'
                        + '</svg> Renvoyer';
                    var self = this;
                    retryBtn.addEventListener('click', function() {
                        if (self.state.isLoading) return;
                        self.el.input.value = rawText;
                        // Si le textarea s'auto-redimensionne, declenche l'event
                        // pour reactiver le sendBtn et ajuster la hauteur.
                        self.el.input.dispatchEvent(new Event('input', { bubbles: true }));
                        self.sendMessage();
                    });
                    meta.appendChild(retryBtn);
                }
            }

            this.el.messages.appendChild(msgDiv);

            // Parse suggestion buttons [BUTTONS:label1|label2|label3]
            if (type === 'assistant' && content && content.indexOf('[BUTTONS:') >= 0) {
                var btnMatch = content.match(/\[BUTTONS:([^\]]+)\]/);
                if (btnMatch) {
                    var labels = btnMatch[1].split('|').map(function(l) { return l.trim(); }).filter(function(l) { return l; });
                    if (labels.length > 0) {
                        var self = this;
                        var chipsDiv = document.createElement('div');
                        chipsDiv.className = 'bzk-chat-suggestions';
                        labels.forEach(function(label) {
                            var chip = document.createElement('button');
                            chip.className = 'bzk-chat-chip';
                            chip.textContent = label;
                            chip.onclick = function() {
                                chipsDiv.remove();
                                self.sendMessage(label);
                            };
                            chipsDiv.appendChild(chip);
                        });
                        this.el.messages.appendChild(chipsDiv);
                    }
                    // Remove the tag from the visible message
                    var bubble = msgDiv.querySelector('.bzk-chat-msg-bubble');
                    if (bubble) bubble.innerHTML = bubble.innerHTML.replace(/\[BUTTONS:[^\]]+\]/, '').trim();
                }
            }

            this.scrollToBottom();
        },

        /**
         * Convertit le markdown basique en HTML pour les messages assistant
         */
        renderMarkdown: function (text) {
            if (!text) return '';
            // Escape HTML first for security
            var html = this.escapeHtml(text);

            // Bold: **text** or __text__
            html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
            html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');

            // Italic: *text* or _text_ (but not inside words for _)
            html = html.replace(/(?<!\w)\*([^*]+?)\*(?!\w)/g, '<em>$1</em>');
            html = html.replace(/(?<!\w)_([^_]+?)_(?!\w)/g, '<em>$1</em>');

            // Inline code: `code`
            html = html.replace(/`([^`]+?)`/g, '<code style="background:#f1f5f9;padding:1px 4px;border-radius:3px;font-size:0.9em;">$1</code>');

            // Links: [text](url)
            html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener" style="color:#b8860b;text-decoration:underline;">$1</a>');

            // Bare URLs: make clickable
            html = html.replace(/(?<!["\'>=])(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener" style="color:#b8860b;text-decoration:underline;">$1</a>');

            // Unordered lists: lines starting with - or *
            html = html.replace(/^[\-\*]\s+(.+)$/gm, '<li style="margin-left:16px;list-style:disc;">$1</li>');

            // Numbered lists: lines starting with 1. 2. etc
            html = html.replace(/^\d+\.\s+(.+)$/gm, '<li style="margin-left:16px;list-style:decimal;">$1</li>');

            // Wrap consecutive <li> in <ul>/<ol>
            html = html.replace(/((?:<li style="margin-left:16px;list-style:disc;">.*<\/li>\n?)+)/g, '<ul style="margin:4px 0;padding-left:8px;">$1</ul>');
            html = html.replace(/((?:<li style="margin-left:16px;list-style:decimal;">.*<\/li>\n?)+)/g, '<ol style="margin:4px 0;padding-left:8px;">$1</ol>');

            // Line breaks: convert newlines to <br> (but not inside lists)
            html = html.replace(/\n/g, '<br>');

            // Clean up extra <br> around lists
            html = html.replace(/<br>\s*<ul/g, '<ul');
            html = html.replace(/<\/ul>\s*<br>/g, '</ul>');
            html = html.replace(/<br>\s*<ol/g, '<ol');
            html = html.replace(/<\/ol>\s*<br>/g, '</ol>');

            return html;
        },

        showTyping: function () {
            this.el.typing.classList.add('visible');
            this.scrollToBottom();
        },

        hideTyping: function () {
            this.el.typing.classList.remove('visible');
        },

        showEscalation: function () {
            this.el.escalation.classList.add('visible');
            this.el.escalationName.value = '';
            this.el.escalationEmail.value = '';
            this.el.escalationName.style.borderColor = '';
            this.el.escalationEmail.style.borderColor = '';
        },

        hideEscalation: function () {
            this.el.escalation.classList.remove('visible');
        },

        showSatisfaction: function () {
            this.state.satisfactionShown = true;
            this.el.satisfaction.classList.add('visible');
        },

        hideSatisfaction: function () {
            this.el.satisfaction.classList.remove('visible');
        },

        /**
         * Propose la notation en fin de conversation naturelle : 60s
         * d'inactivité après au moins 2 réponses de l'assistant, une seule
         * fois par conversation. (Avant, les étoiles n'apparaissaient
         * qu'après une escalade — 98% des conversations n'étaient jamais
         * sollicitées : 8 notes sur 3165.)
         */
        scheduleSatisfactionPrompt: function () {
            var self = this;
            if (this.state.satisfactionTimer) {
                clearTimeout(this.state.satisfactionTimer);
                this.state.satisfactionTimer = null;
            }
            if (this.state.satisfactionShown) return;

            this.state.satisfactionTimer = setTimeout(function () {
                self.state.satisfactionTimer = null;
                if (self.state.isOpen
                    && !self.state.satisfactionShown
                    && self.state.assistantReplies >= 2
                    && !self.state.isLoading) {
                    self.showSatisfaction();
                }
            }, 60000);
        },

        scrollToBottom: function () {
            var el = this.el.messages;
            setTimeout(function () {
                el.scrollTop = el.scrollHeight;
            }, 50);
        },

        formatTime: function (isoDate) {
            try {
                var d = new Date(isoDate);
                var h = d.getHours().toString();
                var m = d.getMinutes().toString();
                if (h.length < 2) h = '0' + h;
                if (m.length < 2) m = '0' + m;
                return h + ':' + m;
            } catch (e) {
                return '';
            }
        },

        escapeHtml: function (text) {
            if (!text) return '';
            var div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        },

        // ========== STORAGE ==========

        getStoredUuid: function () {
            try {
                return localStorage.getItem(this.config.storageKey) || null;
            } catch (e) {
                return null;
            }
        },

        storeUuid: function (uuid) {
            try {
                localStorage.setItem(this.config.storageKey, uuid);
            } catch (e) {
                // ignore
            }
        },

        removeStoredUuid: function () {
            try {
                localStorage.removeItem(this.config.storageKey);
            } catch (e) {
                // ignore
            }
        },

        // ========== API ==========

        apiCall: function (action, data, onSuccess, onError, method) {
            var url = this.config.apiUrl + '/' + action;
            method = method || 'POST';

            if (method === 'GET' && data) {
                var params = [];
                for (var key in data) {
                    if (data.hasOwnProperty(key) && data[key] !== null && data[key] !== undefined) {
                        params.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
                    }
                }
                if (params.length > 0) {
                    url += '?' + params.join('&');
                }
                data = null;
            }

            var xhr = new XMLHttpRequest();
            xhr.open(method, url, true);
            xhr.setRequestHeader('Content-Type', 'application/json');

            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status >= 200 && xhr.status < 300) {
                        try {
                            var response = JSON.parse(xhr.responseText);
                            if (onSuccess) onSuccess(response);
                        } catch (e) {
                            if (onError) onError(e);
                        }
                    } else {
                        if (onError) onError(new Error('HTTP ' + xhr.status));
                    }
                }
            };

            xhr.onerror = function () {
                if (onError) onError(new Error('Network error'));
            };

            if (data && method !== 'GET') {
                xhr.send(JSON.stringify(data));
            } else {
                xhr.send();
            }
        },

        /**
         * Envoie une erreur client au serveur pour tracking
         */
        reportError: function(errorData) {
            try {
                var msg = (errorData.message || '').toLowerCase();
                var src = (errorData.source || '').toLowerCase();

                // Ignorer les erreurs non corrigeables (extensions, WebViews tiers, réseau)
                var ignore = [
                    'script error',                          // Cross-origin (extensions)
                    'webkit.messagehandlers',                 // iOS Safari extensions
                    'scdynimacbridge',                        // Snapchat WebView
                    'cashbackreminder',                       // Extensions cashback
                    'java object is gone',                    // Android WebView
                    'enabledidusertype',                      // Android WebView
                    'enablebuttonsclicked',                   // Android WebView
                    'object not found matching id',           // Extensions
                    'the object does not support',            // IE/Edge legacy
                    'load failed',                            // Réseau client
                    'failed to fetch',                        // Réseau client
                    'networkerror',                           // Réseau client
                    'unexpected identifier \'unavailable\'',  // Extensions
                    // Wallets crypto (MetaMask, etc.) injectés par des extensions :
                    // window.ethereum.selectedAddress, etc. Rien à voir avec Bizouk.
                    'ethereum',                               // window.ethereum.* (wallets crypto)
                    'selectedaddress',                        // window.ethereum.selectedAddress
                    'web3',                                   // injections web3
                    'metamask',
                    'solana',                                 // Phantom
                    'tronweb', 'tronlink',                    // TronLink
                    // Navigateur lui-même (Firefox / Firefox iOS : mode lecture, etc.)
                    '__firefox__',                            // window.__firefox__.reader, ReferenceError __firefox__
                    'evmask', 'walletrouter', 'web3modal'
                ];
                for (var i = 0; i < ignore.length; i++) {
                    if (msg.indexOf(ignore[i]) !== -1) return;
                }

                // Ignorer les erreurs venant de scripts externes (pas bizouk.com)
                if (src && src.indexOf('bizouk.com') === -1 && src.indexOf('bizouk.com') === -1
                    && src !== '' && src.indexOf('localhost') === -1) {
                    return;
                }

                var xhr = new XMLHttpRequest();
                xhr.open('POST', this.config.apiUrl + '/client-error', true);
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.send(JSON.stringify({
                    conversation_uuid: this.state.conversationUuid,
                    error_message: errorData.message || '',
                    error_source: errorData.source || '',
                    error_line: errorData.line || 0,
                    error_col: errorData.col || 0,
                    error_stack: errorData.stack || '',
                    page_url: window.location.href,
                    user_agent: navigator.userAgent
                }));
            } catch(e) {}
        }
    };

    // Intercepteur global de TOUTES les erreurs JS de la page (pas seulement le chat)
    var _origOnError = window.onerror;
    window.onerror = function(message, source, line, col, error) {
        BzkChat.reportError({
            message: message,
            source: source,
            line: line,
            col: col,
            stack: error ? error.stack : ''
        });
        if (_origOnError) return _origOnError.apply(this, arguments);
        return false;
    };

    // Intercepteur des rejections de promesses non gérées
    window.addEventListener('unhandledrejection', function(event) {
        BzkChat.reportError({
            message: 'Unhandled Promise Rejection: ' + (event.reason ? (event.reason.message || event.reason) : 'unknown'),
            source: 'promise',
            stack: event.reason && event.reason.stack ? event.reason.stack : ''
        });
    });

    // Exposer globalement
    window.BzkChat = BzkChat;

    // Auto-init si l'attribut data-auto-init est présent
    if (document.currentScript && document.currentScript.getAttribute('data-auto-init') !== null) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function () {
                BzkChat.init();
            });
        } else {
            BzkChat.init();
        }
    }
})();
