// sticky-cart.js

$(document).ready(function() {
    var StickyCart = {
        // État
        state: {
            isVisible: false,
            items: stickyCartConfig.items || [],
            total: stickyCartConfig.totalAmount || 0,
            subtotal: stickyCartConfig.subtotal || 0,
            totalFees: stickyCartConfig.totalFees || 0,
            count: stickyCartConfig.itemCount || 0,
            currency: stickyCartConfig.currency || 'EUR',
            currencySymbol: stickyCartConfig.currencySymbol || '€'
        },
        
        // Traductions
        translations: stickyCartConfig.translations || {},
        
        // Éléments jQuery
        $elements: {},
        
        init: function() {
            this.cacheElements();
            this.bindEvents();
            this.checkInitialVisibility();
        },
        
        cacheElements: function() {
            this.$elements = {
                container: $('#sticky-cart-container'),
                itemsContainer: $('#cart-items-container'),
                countBubble: $('#cart-count-bubble'),
                summarySubtotal: $('#summary-subtotal'),
                summaryFees: $('#summary-fees'),
                summaryTotal: $('#summary-total'),
                continueBtn: $('#continue-booking'),
                modifyBtn: $('#modify-cart'),
                closeBtn: $('#close-cart'),
                toggleTab: $('.cart-toggle-tab'),
                mobileBar: $('#mobile-cart-bar'),
                mobileCount: $('#mobile-cart-count'),
                mobileTotal: $('#mobile-cart-total'),
                mobileContinueBtn: $('#mobile-cart-continue')
            };
        },
        
        bindEvents: function() {
            var self = this;
            
            // Toggle ouverture/fermeture
            this.$elements.toggleTab.on('click', function() {
                self.toggle();
            });
            
            // Fermer le panier
            this.$elements.closeBtn.on('click', function() {
                self.hide();
            });
            
            // Continuer la réservation
            this.$elements.continueBtn.on('click', function() {
                self.continueBooking();
            });
            
            // Modifier le panier
            this.$elements.modifyBtn.on('click', function() {
                self.hide();
                self.scrollToTicketing();
            });
            
            // Bouton continuer mobile
            this.$elements.mobileContinueBtn.on('click', function() {
                self.continueBooking();
            });

            // Écouter les changements de quantité
            $(document).on('change', '.selectQuantity', function() {
                self.updateFromTicketing();
            });

            // Supprimer un article du panier
            $(document).on('click', '.cart-item-remove', function(e) {
                e.stopPropagation();
                var productId = $(this).closest('.cart-item').data('product-id');
                self.setProductQuantity(productId, 0);
            });

            // Modifier la quantité depuis le panier.
            // Respecte la même limite max/min que les boutons +/- de la billetterie :
            //   - sur les widgets <input type="text" data-max="..."> (place_select.phtml
            //     reservation, utilisé par /events/details/*), on lit data-max et data-min
            //   - fallback sur option:last/option:first pour les vieux widgets <select>
            //     (place_select.phtml booking sell)
            // Sans ce fix, l'orga pouvait ajouter X billets sans limite depuis le sticky
            // alors que la billetterie elle-même cappait correctement.
            $(document).on('click', '.cart-item-qty-btn', function(e) {
                e.stopPropagation();
                var productId = $(this).closest('.cart-item').data('product-id');
                var delta = $(this).data('delta');
                var $select = $('.selectQuantity[product="' + productId + '"]');
                if (!$select.length) return;

                var current = parseInt($select.val()) || 0;
                var newVal = current + delta;

                // Min : data-min (widget input) puis 0 par défaut
                var dataMin = $select.data('min');
                var minVal = (dataMin !== undefined && dataMin !== '') ? parseInt(dataMin) : 0;
                // Fallback select : 1re option si elle existe
                if (isNaN(minVal)) minVal = 0;
                var firstOption = $select.find('option:first').val();
                if (firstOption !== undefined) {
                    var fo = parseInt(firstOption);
                    if (!isNaN(fo) && fo > minVal) minVal = fo;
                }

                // Max : data-max (widget input) puis option:last (widget select)
                var dataMax = $select.data('max');
                var maxVal = (dataMax !== undefined && dataMax !== '') ? parseInt(dataMax) : NaN;
                if (isNaN(maxVal)) {
                    var lastOption = $select.find('option:last').val();
                    if (lastOption !== undefined) maxVal = parseInt(lastOption);
                }

                if (newVal < minVal) newVal = minVal;
                if (!isNaN(maxVal) && newVal > maxVal) newVal = maxVal;

                if (newVal !== current) {
                    $select.val(newVal).trigger('change');
                    // Met aussi à jour l'état visuel des boutons +/- de la billetterie
                    // (qui s'appuient sur .has-qty / disabled).
                    var $group = $select.closest('.qty-btn-group');
                    if ($group.length) {
                        $group.find('.qty-minus').prop('disabled', newVal <= minVal);
                        $group.find('.qty-plus').prop('disabled', !isNaN(maxVal) && newVal >= maxVal);
                        $group.toggleClass('has-qty', newVal > 0);
                    }
                }
            });

            // Fermer en cliquant en dehors
            $(document).on('click', function(e) {
                if (self.state.isVisible &&
                    !$(e.target).closest('.sticky-cart-container').length) {
                    self.hide();
                }
            });
        },
        
        checkInitialVisibility: function() {
            // Si la page n'a qu'UN seul tarif, le SELECT a une valeur par défaut
            // (1) ce qui ferait apparaître le sticky immédiatement même sans
            // action utilisateur. On attend une vraie interaction (changement
            // de quantité) avant d'ouvrir le sticky dans ce cas.
            var productCount = $('.selectQuantity').length;
            var hasMultipleProducts = productCount > 1;
            if (!hasMultipleProducts) {
                // On garde la barre mobile à jour (bas d'écran) mais on n'ouvre
                // pas le panel desktop.
                this.updateMobileBar();
                return;
            }

            // N'afficher le sticky cart que s'il y a déjà des items sélectionnés
            if (this.state.count > 0) {
                if (this.isDesktop()) {
                    this.$elements.container.show();
                    this.show();
                } else {
                    this.updateMobileBar();
                }
            }
        },
        
        isOnBookingPage: function() {
            return $('[name="ticketing"]').length > 0 || window.location.pathname.includes('/soirees/details/');
        },
        
        show: function() {
            this.$elements.container.show().addClass('active');
            this.state.isVisible = true;
        },
        
        hide: function() {
            this.$elements.container.removeClass('active');
            this.state.isVisible = false;
        },
        
        toggle: function() {
            if (this.state.isVisible) {
                this.hide();
            } else {
                this.show();
            }
        },
        
        updateFromTicketing: function() {
            var self = this;
            var items = [];
            var subtotal = 0;
            var totalFees = 0;
            var count = 0;
            
            $('.selectQuantity').each(function() {
                var $select = $(this);
                var quantity = parseInt($select.val()) || 0;
                
                if (quantity > 0) {
                    var productId = $select.attr('product');
                    var price = parseFloat($select.attr('price')) || 0;
                    var fee = parseFloat($select.attr('fee')) || 0;
                    
                    // Récupérer le nom du produit
                    var $panel = $select.closest('.panel-body');
                    var name = '';
                    
                    // Stratégie 1: Chercher le premier span avec font-weight:bold dans le panel
                    var $nameElement = $panel.find('span[style*="font-weight:bold"]').first();
                    if ($nameElement.length > 0) {
                        // Cloner pour ne pas affecter l'original, retirer les enfants (comme <s>)
                        var $clone = $nameElement.clone();
                        $clone.find('*').remove();
                        name = $clone.text().trim();
                    }
                    
                    // Stratégie 2: Si toujours pas de nom, chercher avant .produit_prix
                    if (!name) {
                        var $prixDiv = $panel.find('.produit_prix').first();
                        if ($prixDiv.length > 0) {
                            var $prevSpan = $prixDiv.parent().find('span').first();
                            if ($prevSpan.length > 0 && !$prevSpan.hasClass('produit_prix')) {
                                name = $prevSpan.text().trim();
                            }
                        }
                    }
                    
                    // Stratégie 3: Chercher dans le panel-body directement
                    if (!name) {
                        var $firstSpan = $panel.find('> span').first();
                        if ($firstSpan.length > 0) {
                            name = $firstSpan.text().trim();
                        }
                    }
                    
                    // Fallback
                    if (!name || name === '') {
                        name = self.translations.ticket || 'Billet';
                    }
                    
                    // Nettoyer le nom des balises HTML et caractères spéciaux
                    name = name.replace(/<\/?[^>]+(>|$)/g, '');
                    name = name.replace(/[\n\r\t]/g, ' ');
                    name = name.trim();
                    
                    var itemSubtotal = quantity * price;
                    var itemFees = quantity * fee;
                    
                    subtotal += itemSubtotal;
                    totalFees += itemFees;
                    count += quantity;
                    
                    items.push({
                        productId: productId,
                        name: name,
                        quantity: quantity,
                        unitPrice: price,
                        fee: fee,
                        total: itemSubtotal + itemFees
                    });
                    
                    console.log('Produit trouvé:', {
                        name: name,
                        price: price,
                        fee: fee,
                        quantity: quantity,
                        panel: $panel.html()
                    });
                }
            });
            
            // Détecter si c'est le premier ajout (passage de 0 à > 0)
            var wasEmpty = this.state.count === 0 || !this.$elements.container.is(':visible');

            this.state.items = items;
            this.state.subtotal = subtotal;
            this.state.totalFees = totalFees;
            this.state.total = subtotal + totalFees;
            this.state.count = count;

            console.log('État final:', this.state);

            this.updateUI();

            if (count > 0) {
                if (this.isDesktop()) {
                    this.$elements.container.show();
                    this.animateCountBadge();
                    // Ouvrir automatiquement sur desktop au premier article ajouté
                    if (wasEmpty) {
                        this.show();
                    }
                }
                // Toujours mettre à jour la barre mobile
                this.updateMobileBar();
            } else {
                if (this.isDesktop()) {
                    this.hide();
                    this.$elements.container.hide();
                }
                this.updateMobileBar();
            }
        },

        isDesktop: function() {
            return window.innerWidth > 768;
        },

        updateMobileBar: function() {
            if (this.state.count > 0) {
                this.$elements.mobileCount.text(this.state.count);
                this.$elements.mobileTotal.text(this.state.currencySymbol + this.state.total.toFixed(2));
                this.$elements.mobileBar.show();
            } else {
                this.$elements.mobileBar.hide();
            }
        },
        
        updateUI: function() {
            // Mettre à jour les totaux
            this.$elements.summarySubtotal.text(this.state.currencySymbol + this.state.subtotal.toFixed(2));
            this.$elements.summaryTotal.text(this.state.currencySymbol + this.state.total.toFixed(2));
            
            // Mettre à jour les frais si présents
            if (this.state.totalFees && this.state.totalFees > 0) {
                var $feesLine = this.$elements.summaryFees.closest('.summary-line');
                if ($feesLine.length === 0) {
                    // Ajouter la ligne des frais si elle n'existe pas
                    var feesHtml = `
                        <div class="summary-line">
                            <span class="summary-label">${this.translations.paymentFees}:</span>
                            <span class="summary-value" id="summary-fees">${this.state.currencySymbol}${this.state.totalFees.toFixed(2)}</span>
                        </div>
                    `;
                    $('.summary-total').before(feesHtml);
                    this.$elements.summaryFees = $('#summary-fees');
                } else {
                    this.$elements.summaryFees.text(this.state.currencySymbol + this.state.totalFees.toFixed(2));
                }
            } else {
                // Supprimer la ligne des frais si pas de frais
                this.$elements.summaryFees.closest('.summary-line').remove();
            }
            
            // Mettre à jour le compte
            this.$elements.countBubble.text(this.state.count);
            
            // Mettre à jour la liste des items
            this.$elements.itemsContainer.html(this.renderItems());
            
            // Activer/désactiver les boutons
            var hasItems = this.state.count > 0;
            this.$elements.continueBtn.prop('disabled', !hasItems);
        },
        
        renderItems: function() {
            if (this.state.items.length === 0) {
                return `
                    <div class="empty-cart">
                        <i class="fa fa-shopping-basket"></i>
                        <p>${this.translations.cartEmpty}</p>
                    </div>
                `;
            }
            
            var self = this;
            return this.state.items.map(function(item, index) {
                var priceHtml = `<span class="item-price">${self.state.currencySymbol}${(item.unitPrice * item.quantity).toFixed(2)}</span>`;
                var feeHtml = '';

                if (item.fee > 0) {
                    feeHtml = `<span class="item-fee">+ ${self.state.currencySymbol}${(item.fee * item.quantity).toFixed(2)} ${self.translations.fees}</span>`;
                }

                return `
                    <div class="cart-item ${index === self.state.items.length - 1 ? 'new-item' : ''}" data-product-id="${item.productId}">
                        <div class="item-info">
                            <span class="item-name">${item.name}</span>
                            <div class="item-details">
                                <div class="item-qty-controls">
                                    <button type="button" class="cart-item-qty-btn" data-delta="-1" title="-">−</button>
                                    <span class="item-qty-value">${item.quantity}</span>
                                    <button type="button" class="cart-item-qty-btn" data-delta="1" title="+">+</button>
                                </div>
                                <div class="item-price-details">
                                    ${priceHtml}
                                    ${feeHtml}
                                </div>
                            </div>
                        </div>
                        <button type="button" class="cart-item-remove" title="${self.translations.remove || 'Supprimer'}">×</button>
                    </div>
                `;
            }).join('');
        },
        
        animateCountBadge: function() {
            this.$elements.countBubble.addClass('pulse');
            setTimeout(() => {
                this.$elements.countBubble.removeClass('pulse');
            }, 600);
        },
        
        continueBooking: function() {
            var $form = $('form[name="place"]');
            if ($form.length) {
                this.$elements.continueBtn
                    .html(`<i class="fa fa-spinner fa-spin"></i> ${this.translations.pleaseWait}`)
                    .prop('disabled', true);
                $form.submit();
            }
        },
        
        scrollToTicketing: function() {
            var $ticketingSection = $('[name="ticketing"]');
            if ($ticketingSection.length) {
                var offset = $ticketingSection.offset().top - 100;
                $('html, body').animate({
                    scrollTop: offset
                }, 500);
            }
        },
        
        setProductQuantity: function(productId, quantity) {
            var $select = $('.selectQuantity[product="' + productId + '"]');
            if ($select.length) {
                $select.val(quantity).trigger('change');
            }
        },

        // API publique
        updateCart: function(cartData) {
            if (cartData) {
                var self = this;
                this.state.items = cartData.items || [];
                this.state.total = cartData.totalAmount || 0;
                
                // Recalculer subtotal et frais
                this.state.subtotal = 0;
                this.state.totalFees = 0;
                
                this.state.items.forEach(function(item) {
                    var unitPrice = item.unitPrice || 0;
                    var quantity = item.quantity || 0;
                    var fee = item.fee || 0;
                    
                    self.state.subtotal += unitPrice * quantity;
                    self.state.totalFees += fee * quantity;
                });
                
                this.state.count = cartData.itemCount || 0;
                
                console.log('updateCart appelé avec:', cartData);
                console.log('État après mise à jour:', this.state);
                
                this.updateUI();
                
                if (this.state.count > 0) {
                    this.$elements.container.show();
                    // Optionnel : ouvrir automatiquement lors d'un ajout
                    // this.show();
                }
            }
        }
    };
    
    // Initialiser
    StickyCart.init();
    
    // Exposer l'API publique
    window.stickyCart = StickyCart;
});