/*!
 * https://css-tricks.com/snippets/jquery/smooth-scrolling/
 * Updated for jQuery 3+ compatibility
 */

$(document).ready(function() {
  // Select all links with hashes
  $(document).on('click', 'a', function(e) {
    // Get the href attribute
    var href = $(this).attr('href');
    
    // Check if href exists and contains a hash
    if (!href || href.indexOf('#') === -1) {
      return;
    }
    
    // Skip if it's just a '#'
    if (href === '#') {
      return;
    }
    
    // Check if it's an internal link
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      // Figure out element to scroll to
      var hash = this.hash;
      var target = $(hash);
      
      // Does a scroll target exist?
      if (target.length) {
        // Only prevent default if animation is actually gonna happen
        e.preventDefault();
        
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 1000, function() {
          // Callback after animation
          // Must change focus!
          var $target = $(target);
          $target.focus();
          if ($target.is(":focus")) { // Checking if the target was focused
            return false;
          } else {
            $target.attr('tabindex', '-1'); // Adding tabindex for elements not focusable
            $target.focus(); // Set focus again
          }
        });
      }
    }
  });
});